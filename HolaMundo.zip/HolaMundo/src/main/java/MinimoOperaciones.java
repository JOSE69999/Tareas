public class MinimoOperaciones {

        public int[] minOperations(String boxes) {
            int n = boxes.length();
            int[] left = new int[n];
            int[] right = new int[n];
            int[] result = new int[n];

            left[0] = boxes.charAt(0) == '1' ? 1 : 0;
            for (int i = 1; i < n; i++) {
                left[i] = left[i - 1] + (boxes.charAt(i) == '1' ? 1 : 0);
            }

            right[n - 1] = boxes.charAt(n - 1) == '1' ? 1 : 0;
            for (int i = n - 2; i >= 0; i--) {
                right[i] = right[i + 1] + (boxes.charAt(i) == '1' ? 1 : 0);
            }

            for (int i = 0; i < n; i++) {
                int leftOps = (i + 1) * left[i];
                int rightOps = (n - i - 1) * right[i];
                result[i] = leftOps + rightOps;
            }

            return result;
        }

        public static void main(String[] args) {
            MinimoOperaciones mo = new MinimoOperaciones();
            String cajas = "110";  // Ejemplo de entrada
            int[] resultado = mo.minOperations(cajas);

            // Imprimir el resultado
            System.out.print("Resultado: [");
            for (int i = 0; i < resultado.length; i++) {
                System.out.print(resultado[i]);
                if (i < resultado.length - 1) {
                    System.out.print(", ");
                }
            }
            System.out.println("]");
        }
    }

