import java.util.*;

public class ConvertirArreglo {
    public int[][] groupNumbers(int[] nums) {
        Map<Integer, Set<Integer>> map = new HashMap<>();

        for (int num : nums) {
            if (!map.containsKey(num)) {
                map.put(num, new HashSet<>());
            }
            map.get(num).add(num);
        }

        List<int[]> resultList = new ArrayList<>();
        for (Set<Integer> set : map.values()) {
            resultList.add(set.stream().mapToInt(Integer::intValue).toArray());
        }

        return resultList.toArray(new int[resultList.size()][]);
    }

    public static void main(String[] args) {
        ConvertirArreglo ca = new ConvertirArreglo();
        int[] nums = {1,3,4,1,2,3,1};  // Ejemplo de entrada
        int[][] resultado = ca.groupNumbers(nums);

        // Imprimir el resultado
        System.out.println("Resultado:");
        for (int[] row : resultado) {
            System.out.println(Arrays.toString(row));
        }
    }
}