import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class AgruparPersonas {
    public List<List<Integer>> groupThePeople(int[] groupSizes) {
        HashMap<Integer, List<Integer>> map = new HashMap<>();
        List<List<Integer>> result = new ArrayList<>();

        for (int i = 0; i < groupSizes.length; i++) {
            int size = groupSizes[i];
            if (!map.containsKey(size)) {
                map.put(size, new ArrayList<>());
            }
            map.get(size).add(i);
            if (map.get(size).size() == size) {
                result.add(new ArrayList<>(map.get(size)));
                map.get(size).clear();
            }
        }

        return result;
    }

    public static void main(String[] args) {
        AgruparPersonas ap = new AgruparPersonas();
        int[] groupSizes = {3,3,3,3,3,1,3};  // Ejemplo de entrada
        List<List<Integer>> resultado = ap.groupThePeople(groupSizes);

        // Imprimir el resultado
        System.out.println("Resultado: " + resultado);
    }
}
