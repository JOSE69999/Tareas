import java.util.Arrays;

public class OrdenarPorFrecuencia {
    public int[] frequencySort(int[] nums) {
        int max = Arrays.stream(nums).max().getAsInt();
        int[] freq = new int[max + 1];
        for (int num : nums) {
            freq[num]++;
        }

        int index = 0;
        for (int i = 0; i <= max; i++) {
            while (freq[i] > 0) {
                nums[index++] = i;
                freq[i]--;
            }
        }

        return nums;
    }

    public static void main(String[] args) {
        OrdenarPorFrecuencia opf = new OrdenarPorFrecuencia();
        int[] nums = {4,3,1,6,3,4,4,6};  // Ejemplo de entrada
        int[] resultado = opf.frequencySort(nums);

        // Imprimir el resultado
        System.out.println("Resultado: " + Arrays.toString(resultado));
    }
}
